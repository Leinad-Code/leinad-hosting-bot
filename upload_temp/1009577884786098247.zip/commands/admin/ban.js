const Discord = require("discord.js")
const config = require('../../config.json')

module.exports = {
    name: "ban", // Coloque o nome do comando do arquivo

    run: async (client, message, args) => {

        if (!message.member.permissions.has("BAN_MEMBERS")) return message.reply(`❌ ${message.author} | Você não possui permissão para utilizar este comando.`)

        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        const reason = args[1];

        if (!user) return message.reply({
            embeds: [new Discord.MessageEmbed()
                .setColor(config.embed_color)
                .setDescription(`❌ Houve um erro ao tentar banir o usuário.\n\n> Você precisa informar o usuário, veja o exemplo abaixo:\n\n**${config.prefix}ban** \`[user]\` \`[motivo]\``)]
        })

        user.ban({ reason: reason || 'Não definido.' }).then(() => message.reply(`<a:confirm:1059412548824334336> O usuário (${user})[\`${user.tag}\`] foi banido com sucesso.`)).catch(e => {
            message.reply(`❌ Não foi possível banir o usuário \`${user.tag}\`.`)
        })
    }
}