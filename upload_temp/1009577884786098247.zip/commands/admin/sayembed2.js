const Discord = require("discord.js")
const config = require('../../config.json')

module.exports = {
    name: "sayembed2", // Coloque o nome do comando do arquivo

    run: async (client, message, args) => {
        if (!message.member.permissions.has("ADMINISTRADOR")) return message.reply(`❌ ${message.author} | Você não possui permissão para utilizar este comando.`)

        const image = args[0];
        const msg = args.slice(1).join(" ")
        if (!msg || !image) return message.reply(`❌ | ${message.author} Você precisa escrever algo para eu falar!`); //verificando se há alguma mensagem

        message.delete().then(() => {
            message.channel.send({
                embeds: [
                    new Discord.MessageEmbed()
                        .setColor(config.embed_color)
                        .setDescription(`${msg}`)
                        .setImage(image)
                ]
            })
        })
    }
}