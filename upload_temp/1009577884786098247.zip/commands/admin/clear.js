const Discord = require("discord.js");

module.exports = {
    name: "clear",

    run: async (client, message, args) => {
        if (!message.member.permissions.has("MANAGE_MESSAGES")) return message.reply(`❌ ${message.author} | Você não possui permissão para utilizar este comando.`)

        const quantity = parseInt(args[0], 10);

        if (!quantity || quantity < 1 || quantity > 99) return message.reply(`❌ ${message.author} | Você precisa inserir um valor entre **[**\`1-99\`**]**`);

        const messages = await message.channel.messages.fetch({
            limit: quantity + 1
        });

        message.channel.bulkDelete(messages).catch(() => { return; }).then(() => {
            message.channel.send(`<a:confirm:1059412548824334336> | O chat teve \`${quantity}\` mensagens deletadas por ${message.author}`).then(msg => { setTimeout(() => { msg.delete().catch(() => { return; }) }, 10000) })
        })
    }
};