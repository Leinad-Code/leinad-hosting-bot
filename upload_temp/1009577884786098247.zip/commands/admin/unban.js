const Discord = require("discord.js")
const config = require('../../config.json');

module.exports = {
    name: "unban", // Coloque o nome do comando do arquivo

    run: async (client, message, args) => {
        if (!message.member.permissions.has("BAN_MEMBERS")) return message.reply(`❌ ${message.author} | Você não possui permissão para utilizar este comando.`)

        const user = client.users.cache.get(args[0])

        if (!user) return message.reply({
            embeds: [
                new Discord.MessageEmbed()
                    .setColor(config.embed_color)
                    .setDescription(`❌ Houve um erro ao tentar desbanir o usuário.\nVocê precisa informar o usuário, veja o exemplo abaixo:\n\n**${config.prefix}unban** \`[user]\``)
            ]
        })

        message.guild.members.unban(user.id).then(() => message.reply(`<a:confirm:1059412548824334336> O usuário (${user})[\`${user.tag}\`] foi desbanido com sucesso.`)).catch(e => {
            message.reply(`❌ Não foi possível desbanir o usuário \`${user.tag}\`.`)
        })
    }
}