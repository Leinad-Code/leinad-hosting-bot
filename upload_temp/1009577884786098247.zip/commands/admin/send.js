const Discord = require("discord.js")
const config = require('../../config.json')

module.exports = {
    name: "send", // Coloque o nome do comando do arquivo

    run: async (client, message, args) => {
        if (!message.member.permissions.has("ADMINISTRADOR")) return message.reply(`❌ ${message.author} | Você não possui permissão para utilizar este comando.`)

        const types = ['pix', 'email', 'vendas']

        const msg_type = args[0];
        if (!types.find(t => t === msg_type)) return message.reply({
            embeds: [
                new Discord.MessageEmbed()
                    .setColor(config.embed_color)
                    .setDescription(`❌ | ${message.author} Você precisa escrever algo para eu falar, veja o exemplo abaixo:\n\n**.say** \`${types.join(', ')}\``)
            ]
        });

        if (msg_type === "pix") {
            message.delete().then(() => {
                message.channel.send({
                    embeds: [
                        new Discord.MessageEmbed()
                            .setColor(config.embed_color)
                            .setDescription(`Você pode realizar o pagamento via PIX seja ele QR Code ou pagamento normal, as credências está logo abaixo. Lembre-se que antes de realizar qualquer pagamento você enviar o comprovante!`)
                            .addFields(
                                { name: '✉️ Pix (email)', value: `\`\`\`contatodanielsilvaoficial@gmail.com\`\`\`` },
                                { name: '🌐 Pix (chave aleatória)', value: `\`\`\`9cf8dfa8-06a5-45e0-8fa0-f6526e32ef1b\`\`\`` },
                                { name: '👤 Nome cadastrado (primeiro nome)', value: `\`\`\`Jaqueline\`\`\`` }
                            ),
                        new Discord.MessageEmbed()
                            .setColor(config.embed_color)
                            .setDescription(`Aponte a camera do seu celular e escaneie o QR CODE apresentado abaixo:`)
                            .setImage('https://cdn.discordapp.com/attachments/1037732718290665573/1064814359685103657/mercadopago_pixQr.png')
                    ]
                })
            })
        } else if (msg_type === "email") {
            message.delete().then(() => {
                message.channel.send({
                    embeds: [
                        new Discord.MessageEmbed()
                            .setColor(config.embed_color)
                            .setDescription(`Email para contato:\n\`contatodanielsilvaoficial@gmail.com\``),
                    ],
                    components: [
                        new Discord.MessageActionRow()
                            .addComponents(
                                new Discord.MessageButton()
                                    .setStyle('LINK')
                                    .setLabel('Enviar e-mail')
                                    .setEmoji('✉️')
                                    .setURL('https://contatodanielsilvaoficial@gmail.com')
                            )
                    ]
                })
            })
        } else if (msg_type === "vendas") {
            message.delete().then(() => {
                message.channel.send({
                    embeds: [
                        new Discord.MessageEmbed()
                            .setColor(config.embed_color)
                            .setDescription(`Nossa loja possui um sistema de compra 100% automática, ao realizar qualquer compra automaticamente entregamos para você o seu produto.`),
                    ],
                })
            })
        }
    }
}