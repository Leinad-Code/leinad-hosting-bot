const Discord = require("discord.js")
const config = require('../../config.json');

module.exports = {
    name: "kick", // Coloque o nome do comando do arquivo

    run: async (client, message, args) => {
        if (!message.member.permissions.has("KICK_MEMBERS")) return message.reply(`❌ ${message.author} | Você não possui permissão para utilizar este comando.`)

        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        const reason = args[1];

        if (!user) return message.reply({
            embeds: [new Discord.MessageEmbed()
                .setColor(config.embed_color)
                .setDescription(`❌ Houve um erro ao tentar expulsar o usuário.\n\n> Você precisa informar o usuário, veja o exemplo abaixo:\n\n**${config.prefix}kick** \`[user]\` \`[motivo]\``)]
        })

        user.kick(reason || 'Não definido.').then(() => message.reply(`<a:confirm:1059412548824334336> O usuário (${user})[\`${user.tag}\`] foi expulso com sucesso.`)).catch(e => {
            message.reply(`❌ | Não foi possível expulsar o usuário \`${user.tag}\`.`)
        })
    }
}
